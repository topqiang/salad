<?php
	//该配置文件配置NPC-SERVER的服务器地址和端口号
	return array(
		'server'		=>	'127.0.0.1',	//NPC-SERVER的IP地址
		'port'			=>	'9108',		//NPC-SERVER的PORT号
		'merId'			=>	'199108',		//商户编号
		'serverLocation'	=>	'http://mertest.chinapnr.com/muser/publicRequests',			//托管平台地址
	);
?>